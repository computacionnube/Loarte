﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComprayVentaDeVehiculos
{
    public partial class RegistrarVenta : Form
    {
        //Declaracion de variables para recibir datos de otro formulario
        string nombres;
        string apellidos;
        string direcciones;
        string correos;
        string marcas;
        string modelos;
        int años;
        int valores;
        int cedulas;
        int telefonos;
        string colores;
        int motores;
        double cilindrajes;
        int ncahisis;
        int tasmisiones;
        int capcarga;
        int capconbustible;

        public RegistrarVenta(int cedula,string nombre,string apellido,string direccion,int telefono,string correo,string marca,string modelo,int año, int valor,string color,int motor,double cilindraje,int chasis,int trasmision,int capcarga,int capgasolina)
        {
            InitializeComponent();
            //Instanciamos las variables e igualamos
         this.nombres=nombre;
         this.cedulas = cedula;
         this.apellidos = apellido;
         this.direcciones = direccion;
         this.telefonos = telefono;
         this.correos = correo;
         this.marcas = marca;
         this.modelos = modelo;
         this.años = año;
         this.valores = valor;
         this.colores = color;
         this.motores = motor;
         this.cilindrajes = cilindraje;
         this.ncahisis = chasis;
         this.tasmisiones = trasmision;
         this.capcarga = capcarga;
         this.capconbustible = capgasolina;
        }

        private void RegistrarVenta_Load(object sender, EventArgs e)
        {
            llenardatos();
        }
        public void llenardatos(){
            
            //if (objRegistrar.DialogResult == DialogResult.OK)
            Venta.Items.Add("El Usuario: " + nombres + " " + apellidos);
            Venta.Items.Add("Con Cedula: " + cedulas);
            Venta.Items.Add("Direccion: " + direcciones);
            Venta.Items.Add("Correo: " + correos);
            Venta.Items.Add("Telefono: " + telefonos);
            Venta.Items.Add("");
            Venta.Items.Add("-----------------------------------------------------------------------------");
            Venta.Items.Add("                             ESPECIFICACIONES");
            Venta.Items.Add("-----------------------------------------------------------------------------");
            Venta.Items.Add("");
            Venta.Items.Add("Realizo la Compra de Un");
            Venta.Items.Add("Vehiculo Con las Siguientes Especificaciones:");
            Venta.Items.Add("-----------------------------------------------------------------------------");
            Venta.Items.Add("");
            Venta.Items.Add("Marca De Vehiculo: " + marcas);
            Venta.Items.Add("Modelo De Vehiculo : " + modelos);
            Venta.Items.Add("Año De Vehiculo: " + años);
            Venta.Items.Add("Color: " + colores);
            Venta.Items.Add("Numero de Motor: " + motores);
            Venta.Items.Add("Numero de Cilindraje: " + cilindrajes);
            Venta.Items.Add("Trasmision: " + tasmisiones);
            Venta.Items.Add("Capacidad De Carga: " + capcarga);
            Venta.Items.Add("Capacidad De Gasolina: " + capconbustible);
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

    }
}
