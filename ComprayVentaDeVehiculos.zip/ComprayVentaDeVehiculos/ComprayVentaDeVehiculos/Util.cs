﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComprayVentaDeVehiculos
{
    class Util
    {
        //Proceso Para Validar Cedula
        public static string validacedula(string cedula, int a)
        {
            int suma = 0, num, aux, aux2 = 0;
            char[] vectorc = cedula.ToArray();
            for (int i = 0; i < a; i++)
            {
                aux = Convert.ToInt32(vectorc[i].ToString());
                if (i == 10 - 1)
                {
                    aux2 = aux;
                    continue;
                }
                string resulsum=vectorc[0].ToString()+vectorc[1].ToString();
                if (resulsum=="24")
                {
                    return "Invalido";
                }
                else
                {
                   
                    if (i % 2 == 0)
                    {
                        num = aux * 2;
                        if (num > 10)
                        {
                            suma +=(num - 9);
                        }
                        else
                        {
                            suma += num;
                        }
                    }
                    else
                    {
                        suma += aux;
                    }
                }
               
            }

            double ced = (suma *10)/100;
            int ced1 = suma / 10;
            if (ced > 0)
            {
                ced1 = (ced1 + 1) * 10;
            }
            int result = (ced1 - suma);
            if (result== aux2 || result>=10)
            {
                return "Valido";
            }
            else
            {
                return "Invalido";
            }
        }
        //Proceso Para Validar Correo
        public static string validacorreo(string correo)
        {
            char[] del = { '@' };
            string[] email = correo.Split(del);
            if (email[0].Length > 1 && email[1].Length > 1)
            {
                return "Valido";
            }
            else
            {
                return "Invalido";
            }
        }
    }
}
