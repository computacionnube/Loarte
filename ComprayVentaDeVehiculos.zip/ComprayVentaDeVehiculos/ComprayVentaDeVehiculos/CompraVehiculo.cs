﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComprayVentaDeVehiculos
{
    public partial class CompraVehiculo : Form
    {
        //Creamos un metodo Get y Set para cara variable que necesitamos ingresar
        private string marca;

        public string Marca
        {
            get { return marca; }
            set { marca = value; }
        }
        private string modelo;

        public string Modelo
        {
            get { return modelo; }
            set { modelo = value; }
        }
        private int año;

        public int Año
        {
            get { return año; }
            set { año = value; }
        }
        private double valor;

        public double Valor
        {
            get { return valor; }
            set { valor = value; }
        }
        private string color;

        public string Color
        {
            get { return color; }
            set { color = value; }
        }

        

        private int N_Motor;

        public int N_Motor1
        {
            get { return N_Motor; }
            set { N_Motor = value; }
        }
        private double cilindraje;

        public double Cilindraje
        {
            get { return cilindraje; }
            set { cilindraje = value; }
        }
        private int N_Chasis;

        public int N_Chasis1
        {
            get { return N_Chasis; }
            set { N_Chasis = value; }
        }
        private int Tranmision;

        public int Tranmision1
        {
            get { return Tranmision; }
            set { Tranmision = value; }
        }
        private int capacidad_Carga;

        public int Capacidad_Carga
        {
            get { return capacidad_Carga; }
            set { capacidad_Carga = value; }
        }
        private int capacidad_Combustible;

        public int Capacidad_Combustible
        {
            get { return capacidad_Combustible; }
            set { capacidad_Combustible = value; }
        }
        private string tipo_pago;

        public string Tipo_pago
        {
            get { return tipo_pago; }
            set { tipo_pago = value; }
        }
           int numero;
           string marcas, modelos,colors,tipo_p;
           int años, valores,motores,n_chasiss,transmisiones,cap_carga,cap_combustible;
           double cilindrajes; 
        public CompraVehiculo(int num,string marca,string moodelo,int año,int valor,string clor, int n_motor,double cilindro,int n_chasis, int transmi, int cap_carg, int cap_cmbust,string tipo)
        {
            InitializeComponent();
            this.numero=num;
            this.marcas = marca;
            this.modelos = moodelo;
            this.años = año;
            this.valores = valor;
            this.colors= clor;
            this.motores=n_motor;
            this.cilindrajes = cilindro;
            this.n_chasiss = n_chasis;
            this.transmisiones = transmi;
            this.cap_carga= cap_carg;
            this.cap_combustible=cap_cmbust;
            this.Tipo_pago = tipo;

        }

        private void CompraVehiculo_FormClosed(object sender, FormClosedEventArgs e)
        {
            //Application.Exit();
        }
        private bool flag;

        public bool Flag
        {
            get { return flag; }
            set { flag = value; }
        }
        //Boton Ocultar Para Regresar
        private void button3_Click(object sender, EventArgs e)
        {
            Form1 objcompra = new Form1();
            this.Hide();
            if (txtaño.Text == "null" || txtmarca.Text == "null" || txtmodelo.Text == "null" || txtvalor.Text == "null" || cbo1.Text == "null")
            {
                Flag = true;
                objcompra.Visible = true;
            }
            else
            {
                Flag = false;
            }
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
                Marca = txtmarca.Text;
                Modelo = txtmodelo.Text;
                Año = int.Parse(txtaño.Text);
                Valor = double.Parse(txtvalor.Text);
                Color = txtColor.Text;
                N_Motor1 = int.Parse(txtNMotor.Text);
                Cilindraje = int.Parse(txtCilindraje.Text);
                N_Chasis1 = int.Parse(txtChasis.Text);
                Tranmision1 = int.Parse(txtTransmision.Text);
                Capacidad_Carga = int.Parse(txtCapacidadaCarga.Text);
                Capacidad_Combustible = int.Parse(txtCapacCombustible.Text);
                Tipo_pago = cbo1.SelectedItem.ToString();

                
        }

        private void CompraVehiculo_Load(object sender, EventArgs e)
        {
            if (numero == 1)
            {
                txtaño.Text = años.ToString();
                txtmarca.Text = marcas;
                txtmodelo.Text = modelos;
                txtvalor.Text = valores.ToString() ;
                txtColor.Text = colors;
                txtNMotor.Text = motores.ToString();
                txtCilindraje.Text = cilindrajes.ToString();
                txtChasis.Text = n_chasiss.ToString();
                txtTransmision.Text = transmisiones.ToString();
                txtCapacidadaCarga.Text = cap_carga.ToString();
                txtCapacCombustible.Text=cap_combustible.ToString();
               
                btnEditar.Visible = true;
                btnGuardarCompra.Visible = false;


            }
        }

        private void txtmarca_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 8 && letra != 13 && letra != 32)
                e.Handled = true;
        }

        private void txtaño_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsNumber(letra) && letra != 8 && letra != 13 && letra != 32)
                e.Handled = true;
        }

        private void txtvalor_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
                Marca = txtmarca.Text;
                Modelo = txtmodelo.Text;
                Año = int.Parse(txtaño.Text);
                Valor = double.Parse(txtvalor.Text);
                Color = txtColor.Text;
                N_Motor1 = int.Parse(txtNMotor.Text);
                Cilindraje = int.Parse(txtCilindraje.Text);
                N_Chasis1 = int.Parse(txtChasis.Text);
                Tranmision1 = int.Parse(txtTransmision.Text);
                Capacidad_Carga = int.Parse(txtCapacidadaCarga.Text);
                Capacidad_Combustible = int.Parse(txtCapacCombustible.Text);
                tipo_pago = cbo1.SelectedItem.ToString();
        }

        private void txtNMotor_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
        }
    }
}
