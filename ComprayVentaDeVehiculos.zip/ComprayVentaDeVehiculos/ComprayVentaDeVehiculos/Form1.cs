﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComprayVentaDeVehiculos
{
    public partial class Form1 : Form
    {
       
        int fila = 0;
        public Form1()
        {
            InitializeComponent();
        }
        private void rdbventa_CheckedChanged(object sender, EventArgs e)
        {
            //Validamos Para Habilitar El GroupBox
            if (rdbventa.Checked == true)
            {
                grupoVenta.Enabled = true;
                btnEliminar.Visible = false;
                btnModificar.Visible = false;
            }
            else
            {
                grupoVenta.Enabled = false;
            }
          
        }
       
        private void rdbcompra_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbcompra.Checked == true)
            {
                CompraVehiculo objcompra = new CompraVehiculo(0,"","",0,0,"",0,0.0,0,0,0,0,"");
               // this.Hide();
                //objcompra.Visible = true;
                //Para Agregar Filas a La DataGriview
                objcompra.ShowDialog();
                if (objcompra.DialogResult == DialogResult.OK )
                {
                    dgv1.Rows.Add(1);
                    fila = dgv1.Rows.Count - 1;
                    dgv1.Rows[fila].Cells[0].Value = objcompra.Marca;
                    dgv1.Rows[fila].Cells[1].Value = objcompra.Modelo;
                    dgv1.Rows[fila].Cells[2].Value = objcompra.Año;
                    dgv1.Rows[fila].Cells[3].Value = objcompra.Valor;
                    dgv1.Rows[fila].Cells[4].Value = objcompra.Color;
                    dgv1.Rows[fila].Cells[5].Value = objcompra.N_Motor1;
                    dgv1.Rows[fila].Cells[6].Value = objcompra.Cilindraje;
                    dgv1.Rows[fila].Cells[7].Value = objcompra.N_Chasis1;
                    dgv1.Rows[fila].Cells[8].Value = objcompra.Tranmision1;
                    dgv1.Rows[fila].Cells[9].Value = objcompra.Capacidad_Carga;
                    dgv1.Rows[fila].Cells[10].Value = objcompra.Capacidad_Combustible;
                    dgv1.Rows[fila].Cells[11].Value = objcompra.Tipo_pago;

                }
            }
            if (dgv1.Rows.Count > 0 )
            {
                    rdbventa.Enabled = true;
                   
            }
          
            rdbcompra.Checked = false;
         
           
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CompraVehiculo objcompra = new CompraVehiculo(0, "", "", 0, 0,"", 0, 0.0, 0, 0, 0, 0,"");
            if (dgv1.Rows.Count <= 0 && objcompra.Flag == true)
            {
                this.Close();
            }
            else if (dgv1.Rows.Count <= 0)
            {
                MessageBox.Show("Debe Ingresar Una Compra", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                rdbventa.Enabled = false;
                rdbcompra.Checked = false;
            }
        }
        //Encapsulamiento De Variables
        private int cedula;

        public int Cedula
        {
            get { return cedula; }
            set { cedula = value; }
        }
        private string nombre;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        private string apellido;

        public string Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }
        private string direccion;

        public string Direccion
        {
            get { return direccion; }
            set { direccion = value; }
        }
        private int telefono;

        public int Telefono
        {
            get { return telefono; }
            set { telefono = value; }
        }
        private string correo;

        public string Correo
        {
            get { return correo; }
            set { correo = value; }
        }
        private string marca;

        public string Marca
        {
            get { return marca; }
            set { marca = value; }
        }
        private string modelo;

        public string Modelo
        {
            get { return modelo; }
            set { modelo = value; }
        }
        private int año;

        public int Año
        {
            get { return año; }
            set { año = value; }
        }
        private int valor;

        public int Valor
        {
            get { return valor; }
            set { valor = value; }
        }
        private string color;

        public string Color
        {
            get { return color; }
            set { color = value; }
        }

        private int motor;

        public int Motor
        {
            get { return motor; }
            set { motor = value; }
        }
        private double cilindraj;

        public double Cilindraj
        {
            get { return cilindraj; }
            set { cilindraj = value; }
        }
        private int nchasis;

        public int Nchasis
        {
            get { return nchasis; }
            set { nchasis = value; }
        }
        private int trasnmi;

        public int Trasnmi
        {
            get { return trasnmi; }
            set { trasnmi = value; }
        }
        private int capCarga;

        public int CapCarga
        {
            get { return capCarga; }
            set { capCarga = value; }
        }
        private int capCombustibl;

        public int CapCombustibl
        {
            get { return capCombustibl; }
            set { capCombustibl = value; }
        }
        private string tipopago;

        public string Tipopago
        {
            get { return tipopago; }
            set { tipopago = value; }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (Marca != null)
            {
                llenardatos();
                RegistrarVenta objRegistrar = new RegistrarVenta(Cedula, Nombre, Apellido, Direccion, Telefono, Correo, Marca, Modelo, Año, Valor,Color,Motor,Cilindraj,Nchasis,Trasnmi,CapCarga,CapCombustibl);
                objRegistrar.Visible = true;
            }
            else
            {
                MessageBox.Show("Error.. Debe Escoger Un Vehiculo Primero");
            }
           
        }
        public void llenardatos()
        {
            Cedula = int.Parse(txtCedula.Text);
            Nombre = txtNombre.Text;
            Apellido = txtApellido.Text;
            Direccion = txtDireccion.Text;
            Telefono = int.Parse(txtTelefono.Text);
            Correo = txtCorreo.Text;
        }

        public void limpiar()
        {
            txtApellido.Clear();
            txtCedula.Clear();
            txtCorreo.Clear();
            txtDireccion.Clear();
            txtNombre.Clear();
            txtTelefono.Clear();
        }

        //Declaramos una variable para poner la posicion de la fila
        int pos = 0;
        private void dgv1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Obtenemos los valores de la DataGriview
           pos = dgv1.CurrentRow.Index;
           Marca= dgv1.Rows[pos].Cells[0].Value.ToString();
           Modelo= dgv1.Rows[pos].Cells[1].Value.ToString();
           Año = int.Parse(dgv1.Rows[pos].Cells[2].Value.ToString());
           Valor = int.Parse(dgv1.Rows[pos].Cells[3].Value.ToString());
           Color = dgv1.Rows[pos].Cells[4].Value.ToString();
           Motor = int.Parse(dgv1.Rows[pos].Cells[5].Value.ToString());
           Cilindraj = double.Parse(dgv1.Rows[pos].Cells[6].Value.ToString());
           Nchasis = int.Parse(dgv1.Rows[pos].Cells[7].Value.ToString());
           Trasnmi = int.Parse(dgv1.Rows[pos].Cells[8].Value.ToString());
           CapCarga = int.Parse(dgv1.Rows[pos].Cells[9].Value.ToString());
           CapCombustibl = int.Parse(dgv1.Rows[pos].Cells[10].Value.ToString());
           Tipopago=dgv1.Rows[pos].Cells[11].Value.ToString();
           btnEliminar.Visible = true;
           btnModificar.Visible = true;
         
        }

        private void btnNueva_Click(object sender, EventArgs e)
        {
            limpiar();
            grupoVenta.Enabled = false;
            rdbventa.Checked = false;
            btnModificar.Visible = false;
            btnEliminar.Visible = false;
        }

        private void txtCedula_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra=e.KeyChar;
            if (!char.IsNumber(letra) && letra != 8 && letra != 13 && letra != 32)
                e.Handled = true;
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 8 && letra != 13 && letra != 32)
                e.Handled = true;
        }

        private void txtCedula_Leave(object sender, EventArgs e)
        {
            string resp;
            resp = Util.validacedula(txtCedula.Text, txtCedula.TextLength);
            if (resp == "Invalido")
            {
                MessageBox.Show("Cedula Incorrecta");
                txtCedula.Clear();
                txtCedula.Focus();//Hacer bien en el leave
            }
        }
        //Declaracion de variables para la validacion de correo
        string mail;
        private void txtCorreo_Leave(object sender, EventArgs e)
        {
           
            if (txtCorreo.Text.Contains("@"))
            {
                mail = Util.validacorreo(txtCorreo.Text);
                saltarlinea();//Falta un mensaje de error para escribir el correo
            }
            else
            {
                MessageBox.Show("Error. Revice su correo");
            }
        }
        //Proceso Para Validar si esta bien o no
        public void saltarlinea()
        {
            if (mail == "Invalido")
            {
                txtCorreo.Clear();
                txtCorreo.Focus();
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            CompraVehiculo datos = new CompraVehiculo(1, Marca, Modelo, Año, Valor, Color, Motor, Cilindraj, Nchasis, Trasnmi, CapCarga, CapCombustibl, Tipopago);
            //datos.Visible = true;
            datos.Text = "Editar Compra";
                           datos.ShowDialog();
                           if (datos.DialogResult == DialogResult.OK)
                           {
                               dgv1.Rows[pos].Cells[0].Value = datos.Marca;
                               dgv1.Rows[pos].Cells[1].Value = datos.Modelo;
                               dgv1.Rows[pos].Cells[2].Value = datos.Año;
                               dgv1.Rows[pos].Cells[3].Value = datos.Valor;
                               dgv1.Rows[pos].Cells[4].Value = datos.Color;
                               dgv1.Rows[pos].Cells[5].Value = datos.N_Motor1;
                               dgv1.Rows[pos].Cells[6].Value = datos.Cilindraje;
                               dgv1.Rows[pos].Cells[7].Value = datos.N_Chasis1;
                               dgv1.Rows[pos].Cells[8].Value = datos.Tranmision1;
                               dgv1.Rows[pos].Cells[9].Value = datos.Capacidad_Carga;
                               dgv1.Rows[pos].Cells[10].Value = datos.Capacidad_Combustible;
                               dgv1.Rows[pos].Cells[11].Value = datos.Tipo_pago;
                           }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            dgv1.Rows.RemoveAt(pos);
            if (dgv1.Rows.Count <= 0)
            {
                    MessageBox.Show("Debe Ingresar Una Compra", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    rdbventa.Enabled = false;
                    rdbcompra.Checked = false;
                    limpiar();
                    grupoVenta.Enabled = false;
                    rdbventa.Checked = false;
            }
        }
    }
}
